__author__ ='Nick chen'

# coding:utf8
import cv2
import time
import imutils
import numpy as np


class CameraHandel(object):
    def __init__(self,cameraindex):
        self.__cameraindex=cameraindex
        self.__camera=None
        self.__frame=None
        self.__grabbed=None


    def Openvideocaptrue(self):
        self.__camera = cv2.VideoCapture(self.__cameraindex)
        print "OPEN THE CAMERA  WAITING...-----Camerahandle.py"
        time.sleep(2)
        if self.__camera.isOpened:
            print "CAMERA OPEN SUCCESSLY!-----Camerahandle.py"
        else:
            print "CAMERA OPEN FAILED!-----Camerahandle.py"

    def Openpreview(self):
        if self.__grabbed == False:
            print "Openpreview is Error!-----Camerahandle.py"
            return
        while True:
            self.__grabbed, self.__frame = self.__camera.read()
            cv2.imshow("Frame", self.__frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.__camera.release()
                cv2.destroyAllWindows()
    def Closepreview(self):
        self.__camera.release()
        cv2.destroyAllWindows()


    def Savepicture(self,savepath):
        for i in range(20):
            self.__grabbed,self.__frame=self.__camera.read()
        cv2.imwrite(savepath,self.__frame)
        time.sleep(2)
        print savepath,'-----Camerahandle.py'

"""
if __name__=='__main__':
    savepath = 'C:\\Users\\37209\\Desktop\\ShopingRobot\\Pic\\'+ "A.jpg"
    camera=CameraHandel(0)
    camera.Openvideocaptrue()
    camera.Savepicture(savepath)

"""






