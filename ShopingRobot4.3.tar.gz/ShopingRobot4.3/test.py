__author__ ='Nick chen'

# coding:utf8
import time
import platform
import serial
from pathplanning.Pathplanning import PathPlanning
from maphandle.Map import  Map
from Shelfhandle.Shelf import Shelf
from warehouse.Warehouse import WareHouse
from robotarm.Robotarm import RobotArm


def serialinit():
    if 'Linux' in platform.platform():
        com1 = serial.Serial(
            '/dev/ttyACM0',
            115200,
            timeout=None,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE)

        com2 = serial.Serial(
            '/dev/ttyACM1',
            115200,
            timeout=None,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE)

    elif 'Windows' in platform.platform():
        com1 = serial.Serial(
            'COM60',
            115200,
            timeout=2,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE)

        com2 = serial.Serial(
            'COM55',
            115200,
            timeout=2,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE)

    else:
        raise RuntimeError('Unsupported platform.')

    time.sleep(4)

    com1_info = com1.readlines()
    com1_info = [line.decode().strip() for line in com1_info]

    if 'start' in com1_info:
        arm_com = com1
        wheel_com=com2

    elif 'wheel' in com1_info:
        wheel_com = com1
        arm_com = com2

    else:
        raise RuntimeError('Serial port 1 (ttyACM0) authentication failed')


    return wheel_com,arm_com

def isComplete(serial):
    while True:
        s = serial.readline()
        print "waiting for feedback...", s
        if "Complete" in s:
            if serial is arm_com:
                time.sleep(1)
                print "arm complete!"
                break
                return True
            elif serial is wheel_com:
                print "wheel complete!"
                break
                return True




if __name__=='__main__':
    map=Map()
    shelf=Shelf('left')
    warehouse=WareHouse()
    robotarm = RobotArm()
    pathpalning=PathPlanning(map.getMap(),map.getStartpoint(),'N')
    wheel_com, arm_com = serialinit()
    arm_com.write(robotarm.armInit())
    time.sleep(15)
    arm_com.write(robotarm.ArmMoveto("up"))
    print('Done Initialize Robot.')