__author__ ='Nick chen'

# coding:utf8
import serial
import time
import serial.tools.list_ports


class SerialConnect(object):
    def __init__(self, system, baudrate):
        self.__serialname = None
        self.__system = system.upper()
        self.__baurate = baudrate
        self.__serialFd = None



    def initSerial(self):
        if 'LINUX'in self.__system:
            self.__serialFd = serial.Serial(
                '/dev/ttyACM0',
                self.__baurate,
                timeout=2,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE)

        elif 'WINDOWS' in self.__system:
            plist = list(serial.tools.list_ports.comports())
            plist_0 = list(plist[0])
            self.__serialname = plist_0[0]
            print self.__serialFd
            self.serialFd = serial.Serial(
                self.__serialname,
                self.__baurate,
                timeout=2,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE)

        else:
            raise RuntimeError('Unsupported platform.-----Serialconnect.py')


        print "OPEN THE SERIAL REPOT......WAITING....-----Serialconnect.py"
        time.sleep(3)  # MUST WAIT FOT SERIAL CONNECTING!!


    def isConnected(self):
        self.__serialFd.write('?'.encode())
        con = self.__serialFd.readlines()
        if 'Acknowledge' in con:
            print "serial  is connectting scusessly!-----Serialconnect.py"
            return True
        else:
            print "Connecting Fail!-----Serialconnect.py"
            return False

    def senddata(self,data):
        self.__serialFd.write(data)
        rcv=self.serialFd.readline()
        if "Acknowledge" in rcv:
            return True
        else:
            return False

    def receive(self):
        return self.serialFd.readlines()


    def getserialname(self):
        return self.__serialname

    def getsystem(self):
        return self.__system

    def getbaurate(self):
        return self.__baurate

    def getserialFd(self):
        return self.__serialFd

    def setbaurate(self, baurate):
        self.__baurate = baurate

"""

"""
if __name__=='__main__':
    serialconnect=SerialConnect('windows',9600)
    serialconnect.initSerial()
    print serialconnect.getserialFd()



