__author__ ='Nick chen'


#2018.3.18 19:08 edited by nick chen



import time
import platform
import serial
from pathplanning.Pathplanning import PathPlanning
from maphandle.Map import  Map
from Shelfhandle.Shelf import Shelf
from warehouse.Warehouse import WareHouse
from robotarm.Robotarm import RobotArm


if __name__=='__main__':
    map=Map()
    shelf=Shelf('left')
    warehouse=WareHouse()
    robotarm = RobotArm()
    pathpalning=PathPlanning(map.getMap(),map.getStartpoint(),'N')
    print('Done Initialize Robot.')


    #after recognizing item_list:
    item_list = {"A": {"left": "yang le duo", "mid": "yellow cube", "right": "red cube"},
                 "B": {"left": "tennis ball", "mid": "apple", "right": "xue bi"},
                 "C": {"left": "blue cube", "mid": "xue hua", "right": "green cube"},
                 "D": {"left": "shuang wai wai", "mid": "steel ball", "right": "badminton"}}

    special_position = ""
    special_area = ""
    special_item=""


    for area in map.getSearch_List("area"):
        item_pos = item_list[area]
        robotarm.initCatchOrder()
        for pos in map.getSearch_List("cargo"):
            item = item_pos[pos]
            if item is None:
                robotarm.delCatchOrder(pos)
                continue

            if item is "apple":
                special_area = area
                special_position = pos
                special_item=item
                robotarm.delCatchOrder(pos)
                continue

            # go to the catching point
            print '-----------------------start-------------------------------------------'
            destination, Existpos = warehouse.getFirst_Existwarehouse(map, area, robotarm.getCatch_Order())
            print 'the coordinate of the first existwarehouse is:%s,position is:%s' % (destination, Existpos)
            pathlist, count = pathpalning.Goto(pathpalning.getCurrentposition(), destination)
            print 'the car will go to the destination... order:%s' % (pathlist)
            catchpath = pathpalning.TurntoCatch(map, pathpalning.getCurrentposition())
            print 'the car will face to the warehouse... order:%s' % (catchpath)

            # begin to catch
            send_list = robotarm.ArmMoveto(Existpos) + robotarm.ArmCatch(robotarm.getItemangle(item))
            print "the robotarm will move to catch... order:%s" % send_list
            print "has the robotarm already caught?:%s" % warehouse.catch_warehouse(area, Existpos)
            print "the robotarm is initializing... order:%s" % robotarm.Standardpose()

            # out of catching point
            print "the car will go back from the warehouse... order:%s" % pathpalning.OverCatchToback()

            # go to the putting point
            point ,level = shelf.getFirst_Emptyshelf(shelf.whereIsItem(item))
            print "the coordinate of the first emptyshelf is %s, position is %s" % (point, level)
            pathlist, count = pathpalning.Goto(pathpalning.getCurrentposition(), point)
            print "the car will  go to the destination... order:%s" % (pathlist)

            # arm to get up/down
            print "the robotarm is preparing to put... order:%s" % robotarm.ArmMoveto(level)

            # ready to put
            putpath = pathpalning.TurntoPut(map, pathpalning.getCurrentposition())
            print 'the car will face to the shelf... order:%s' % (putpath)

            # finishing putting
            print "the robotarm will put %s order:%s" % (item,robotarm.ArmEase())
            print "has the robotarm already put?:%s" % shelf.putShelf(map, pathpalning.getCurrentposition(),shelf.whereIsItem(item), level)


            print "get the list of the shelf: %s,area is :%s " % (str(shelf.get_shelf(shelf.whereIsItem(item))), shelf.whereIsItem(item))

            print "the car will go back from the shelf... order:%s" % pathpalning.OverCatchToback()
            print "the robotarm is initializing... order:%s" % robotarm.Standardpose()
            print '-----------------------end-------------------------------------------'




    # go to the catching point
    print '-----------------------start-------------------------------------------'
    destination, Existpos = warehouse.getFirst_Existwarehouse(map, special_area, robotarm.getCatch_Order())
    print 'the coordinate of the first existwarehouse is:%s,position is:%s' % (destination, Existpos)
    pathlist, count = pathpalning.Goto(pathpalning.getCurrentposition(), destination)
    print 'the car will go to the destination... order:%s' % (pathlist)
    catchpath = pathpalning.TurntoCatch(map, pathpalning.getCurrentposition())
    print 'the car will face to the warehouse... order:%s' % (catchpath)

    # begin to catch
    send_list = robotarm.ArmMoveto(Existpos) + robotarm.ArmCatch(robotarm.getItemangle(special_item))
    print "the robotarm will move to catch... order:%s" % send_list
    print "has the robotarm already caught?:%s" % warehouse.catch_warehouse(special_area, Existpos)
    print "the robotarm is initializing... order:%s" % robotarm.Standardpose()

            # out of catching point
    print "the car will go back from the warehouse... order:%s" % pathpalning.OverCatchToback()

    # go to the putting point
    point, level = shelf.getFirst_Emptyshelf(shelf.whereIsItem(special_item))
    print "the coordinate of the first emptyshelf is %s, position is %s" % (point, level)
    pathlist, count = pathpalning.Goto(pathpalning.getCurrentposition(), point)
    print "the car will  go to the destination... order:%s" % (pathlist)

    # arm to get up/down
    print "the robotarm is preparing to put... order:%s" % robotarm.ArmMoveto(level)

    # ready to put
    putpath = pathpalning.TurntoPut(map, pathpalning.getCurrentposition())
    print 'the car will face to the shelf... order:%s' % (putpath)

    # finishing putting
    print "the robotarm will put %s order:%s" % (special_item, robotarm.ArmEase())
    print "has the robotarm already put?:%s" % shelf.putShelf(map, pathpalning.getCurrentposition(),
                                                                      shelf.whereIsItem(special_item), level)
    print "get the list of the shelf: %s,area is :%s " % (
    str(shelf.get_shelf(shelf.whereIsItem(special_item))), shelf.whereIsItem(special_item))

    print "the car will go back from the shelf... order:%s" % pathpalning.OverCatchToback()
    print "the robotarm is initializing... order:%s" % robotarm.Standardpose()
    print '-----------------------end-------------------------------------------'





    pathlist, count = pathpalning.Goto(pathpalning.getCurrentposition(), map.getStartpoint())
    print "the car will go back to home... order:%s" %pathlist











