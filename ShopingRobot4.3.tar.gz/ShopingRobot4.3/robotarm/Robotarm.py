# coding:utf8

class RobotArm(object):
    def __init__(self):

        self.__catch_order=['left','mid','right']


        self.__Initangle = {'X': -45.0, 'Y': -61.0, 'Z': 0.0}

        self.__CatchleftAngle = {'X':-42.0,'Y':11.0,'Z':38.0}
        self.__CatchmidAngle = {'X':-32.0,'Y':-3.0,'Z':0.0}
        self.__CatchrightAngle = {'X':-41.0,'Y':11.0,'Z':-34.0}

        self.__Putupangle = {'X':0.0,'Y':61.0,'Z':0.0}
        self.__Putlowangle = {'X':-30.0,'Y':6.0,'Z':0.0}

        self.__Itemangle = {"red cube":49 ,"yang le duo":60,"badminton":65,
                          "yellow cube":49 ,"shuang wai wai":49 ,"steel ball":55,
                          "blue cube":49 ,"xue hua":45,"apple":47,
                          "green cube":49,"xue bi":45,"tennis ball":50 }



    def armInit(self):
        return 'M17\nG28\nG95\nG1 X%s Y%s\nG95\nG93 X0.0 Y0.0 Z0.0\nG90\n' %(str(self.__Initangle['X']),str(self.__Initangle['Y']))

    def ArmMoveto(self,position):
        if position is 'mid':
            command = 'G95\nG1 X%s Y%s Z%s\n' %(str(self.__CatchmidAngle['X']),str(self.__CatchmidAngle['Z']) , str(self.__CatchmidAngle['Z']))
            return command

        elif position is 'left':
            command = 'G95\nG1 Z%s\nG1 X%s Y%s\n' %(str(self.__CatchleftAngle['Z']),str(self.__CatchleftAngle['X']),str(self.__CatchleftAngle['Y']))
            return command

        elif position is 'right':
            command = 'G95\nG1 Z%s\nG1 X%s Y%s\n' % (str(self.__CatchrightAngle['Z']), str(self.__CatchrightAngle['X']), str(self.__CatchrightAngle['Y']))
            return command

        elif position is 'low':
            command = 'G95\nG1 X%s Y%s Z%s\n' % (str(self.__Putlowangle['X']), str(self.__Putlowangle['Y']), str(self.__Putlowangle['Z']))
            return command

        elif (position is "up") or (position  is "all"):
            command = 'G95\nG1 X%s Y%s Z%s\n' % (str(self.__Putupangle['X']), str(self.__Putupangle['Y']), str(self.__Putupangle['Z']))
            return command

    def ArmCatch(self,item):
        return 'M280 P0 S%s\n' %str(item)


    def ArmEase(self):
        return 'M280 P0 S0\n'


    def Standardpose(self):
        command = 'G90\nG95\nG1 X:0.0 Y:0.0 Z:0.0\n'
        return command


    def getItemangle(self,item):
        return self.__Itemangle[item]

    def getCatch_Order(self):
        return self.__catch_order

    def delCatchOrder(self, pos):
        self.__catch_order.remove(pos)

    def initCatchOrder(self):
        self.__catch_order = ['left', 'mid', 'right']

if __name__=='__main__':
    from warehouse.Warehouse import WareHouse
    robotarm = RobotArm()
    warehouse = WareHouse()
    command=['left','mid','right','low','up']
    itemlist=warehouse.getItemlist()
    for position in command:
        for item in itemlist:
            print "robotarm.armInit():",robotarm.armInit()
            print "robotarm.ArmMoveto "+ position +":",robotarm.ArmMoveto(position)
            print "robotarm.ArmCatch "+ item + ":",robotarm.ArmCatch(robotarm.getItemangle(item))
            print "robotarm.ArmEase():",robotarm.ArmEase()
            print "robotarm.Standardpose():",robotarm.Standardpose()
            print "-----------------------------------"












